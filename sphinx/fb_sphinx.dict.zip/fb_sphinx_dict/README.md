## Grupo FalaBrasil

### Recursos para o PocketSphinx ou Sphinx-4

- __fb_sphinx.dict__: 
should have one line per word with the word following the phonetic
transcription. If you are using an existing phonetic dictionary do not use
case-sensitive variants like "e" and "E". Instead, all your phones must be
different even in the case-insensitive variation. Sphinxtrain doesn't support
some special characters like "\*" or "/" and supports most of others like "+",
"-" or ":". However, to be safe we recommend you to use alphanumeric-only
phone-set. Replace special characters in the phone-set, like colons, dashes or
tildes, with something alphanumeric. For example, replace "a~" with "aa" to make
it alphanumeric only. Nowadays, even cell phones have gigabytes of memory on
board. There is no sense in trying to save space with cryptic special
characters.

- __fb_sphinx.filler__: 
contains filler phones (not-covered by language model non-linguistic sounds like
breath, "hmm" or laugh). It can contain just silences.

- __fb_sphinx.phone__: 
one phone per line. The number of phones should match the phones used in the
dictionary plus the special SIL phone for silence.

__Copyright 2005-2018 Grupo FalaBrasil__    
__Universidade Federal do Pará__
