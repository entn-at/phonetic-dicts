## Grupo FalaBrasil

### Recursos para o HTK

- __fb\_htkdict.dic__:
dicionário fonético compatível com o HTK 3.4.1

- __fb\_monophones0.list__:
lista de monophones (HMMs), incluindo o fonema de silêncio

- __fb\_monophones1.list__: 
lista de monophones, incluindo o fonema de pausa curta (short-pause sp)
